### Mission: Cards and Keys ###

Physical security is tight, but we need to get in. We need a working member key-card.

A field operative managed to capture digital scans of several key-cards, unfortunately as we have learnt,
the cards are useless without the owner's personal code.

hence we have intercepted nearly 500 candidate passwords from their credential server,
though the data transfer was abruptly terminated mid-session, leaving us with incomplete intel.

We've acquired a copy of their proprietary key-card scanner. 
Find the keycard and password pair, and use it with the key-card scanner to gain access to their records.

Your goal as always will look like: Balance[XXXXXXXX]

We don't play with luck, so i wish you none.
- Grounded_Pig
