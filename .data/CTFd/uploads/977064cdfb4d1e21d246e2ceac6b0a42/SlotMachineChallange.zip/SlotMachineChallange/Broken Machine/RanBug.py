### Produced by B.B.Coding - 2001 ###
# Developed by Carl Body, Jane Waver, Ted Black
# For Annoymous client - NOT TO BE SHARED FURTHER


#import math # While handy, we want as little external factors as possible (requirement change, Ugh!)
import datetime # In talks with the client, we may be able to agree upon an exception

class RanBug:
    def __init__(self, seed):
        self.seed = seed
        self.runs = 0
    
    def generate_value(self):
        result = 0
        
        # Do you really think date_int will ever have an effect?
        # It get buried way deep, I don't know if it will even influence the rounding
        today = datetime.datetime.today()
        date_int = int(f"{today.day}{today.month}{today.year}")
        
        # Truncate microseconds to use whole seconds
        now = datetime.datetime.now().replace(microsecond=0)
        start_of_day = now.replace(hour=0, minute=0, second=0, microsecond=0)
        seconds_today = int((now - start_of_day).total_seconds())
           
        
        result = ((self.seed + self.runs) * seconds_today) + date_int
        # print(f"Debug - seed * date_int: {result}")
        # print("Seconds today: " + str(seconds_today))
    
        result = "0." + str(result)[::-1] # Reverse the number so the output changes faster over time
        result = float(result)
        
        self.runs += 1
        
        # WHOS IDEAR WAS THIS!!! The distrubution is heavily squwed to the upper range. >:(
        #while result > 1:
            #result += 7 + (self.first_n_digits(now.microsecond, 1) / 10)
            #result /= 10;
            #print(result)
            
        return result
    
    def generate_int(self, minInt, maxInt):        
        result = self.generate_value()      
        NewRange = (maxInt - minInt)  
        result = (result * NewRange) + minInt
        return int(result)
        
    def generate_choice(self, symbols):        
        index = int((self.generate_value() * 1000) % len(symbols))
        return symbols[index]
        
        #This will generate without adding to the runs count, identical to generate value
    def pretend_generate(self):
        result = 0
        
        today = datetime.datetime.today()
        date_int = int(f"{today.day}{today.month}{today.year}")
        
        # Truncate microseconds to use whole seconds
        now = datetime.datetime.now().replace(microsecond=0)
        start_of_day = now.replace(hour=0, minute=0, second=0, microsecond=0)
        seconds_today = int((now - start_of_day).total_seconds())
               
        result = ((self.seed + self.runs) * seconds_today) + date_int 
        
        print("===========================")
        print("Seed is: " + str(self.seed))
        print("Run count is: " + str(self.runs))
        # print("seconds today is: " + str(seconds_today))
        # print("and the date is: " + str(date_int))
        print("DATETIME IS: " + str(now))
   
        result = "0." + str(result)[::-1] # Reverse the number so the output changes faster over time
        result = float(result)
        
        print(result)
            
        return result
        
    def reset_runs(self):
        self.runs = 0
        
    # SERIOUSLY DONT JUST ADD STEPS TILL IT WORKS!!!! 
    # This is bloat, who F*c%ing gave me these code monkeys
    #def first_n_digits(self, num, n):
        #return num // 10 ** (int(math.log(num, 10)) - n + 1)



# TESTING
#seed = input("Press Enter Seed")
#generator = RanBug(int(seed))
#print("Final Result: " + str(generator.generate_int(1,100)))

#symbols = ['A', 'B', 'C', 'D', 'E']

#print(generator.generate_choice(symbols))  # Example: 'B'
#print(generator.generate_choice(symbols))  # Example: 'D'
#print(generator.generate_choice(symbols))  # Example: 'A'
