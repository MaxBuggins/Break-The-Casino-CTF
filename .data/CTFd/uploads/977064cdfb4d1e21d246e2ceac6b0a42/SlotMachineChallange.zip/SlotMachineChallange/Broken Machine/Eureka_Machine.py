import tkinter as tk
from tkinter import *
from tkinter import Frame
from tkinter import messagebox
from RanBug import RanBug
import time
import random

SYMBOLS = ['🍎', '🍏', '🍓', '🍍', '🥝']
SYMBOL_PAYOUT = {'🍎': 3, '🍏': 3, '🍓': 4, '🍍': 5, '🥝': 10, '🍒': 500}
SPIN_DELAY = 5  # Millaseconds between spin steps
MIN_SPIN_STEPS = 10
MAX_SPIN_STEPS = 20

MACHINE_ID = '1B38E'


class PokiesGame:
    def __init__(self, root):
        self.generator = RanBug(int(MACHINE_ID, 36))
        self.root = root
        self.start_fruit = '🍎'
        self.credits = 20
        self.bet = 1
        self.spinning = False
        
        self.setup_gui()
        self.update_credits_display()
        self.update_clock()


    def setup_gui(self):
        self.root.title("Pokies")

        # Top bar frame for credits and clock
        top_frame = tk.Frame(self.root)
        top_frame.pack(fill=tk.X, pady=5)
        
        # Credits display 
        self.credit_label = tk.Label(top_frame, font=('Arial', 14))
        self.credit_label.pack(side=tk.BOTTOM)
        
        # Clock display 
        self.clock_label = tk.Label(top_frame, font=('Arial', 14))
        self.clock_label.pack(side=tk.RIGHT, padx=10)
        
        # Bet controls
        bet_frame = tk.Frame(self.root)
        bet_frame.pack(pady=5)
        
        self.bet_label = tk.Label(bet_frame, text=f"Bet: {self.bet}", font=('Arial', 12))
        self.bet_label.pack(side=tk.LEFT, padx=5)
        
        tk.Button(bet_frame, text="MAX", command=self.max_bet).pack(side=tk.LEFT)
        tk.Button(bet_frame, text="^", command=self.increase_bet).pack(side=tk.LEFT)
        tk.Button(bet_frame, text="v", command=self.decrease_bet).pack(side=tk.LEFT)
        tk.Button(bet_frame, text="MIN", command=self.zero_bet).pack(side=tk.LEFT)
        
        # Reels display
        reels_frame = tk.Frame(self.root)
        reels_frame.pack(pady=20)
        
        self.reel_labels = []
        for _ in range(5):
            label = tk.Label(reels_frame, text="?", font=('Arial', 48), width=3)
            label.pack(side=tk.LEFT, padx=10)
            self.reel_labels.append(label)
        
        # Spin button
        self.spin_button = tk.Button(
            self.root, text="SPIN", font=('Arial', 14), 
            command=self.start_spin, width=10, height=2
        )
        self.spin_button.pack(pady=10)


        options_frame = Frame(root)
        options_frame.pack(side = BOTTOM)

        tk.Button(options_frame, text="QUIT", command=self.root.destroy).pack(side = LEFT, padx = 5)
        tk.Button(options_frame, text="SUPPORT", command=self.show_support).pack(side = LEFT, padx = 5)
    


    def get_flag(self):
        messagebox.showinfo("ERROR: [x09]", "ExitCode: [x09] - Integer Overflow.\n"f"Player_Balance + Game_Credits have exceeded An Amounts.\nPleases contact floor staff for assistance.")
        
        
    def update_clock(self):
        current_time = time.strftime('%H:%M:%S')
        self.clock_label.config(text=current_time)
        # 1000 milaseconds is a second GET THIS THROUGH YOUR THICK SKULL
        self.root.after(5000, self.update_clock) 
    
    
    def update_credits_display(self):
        self.credit_label.config(text=f"Credits: {self.credits}")
        if self.credits >= self.bet:
            self.spin_button.config(state=tk.NORMAL)
        else:
            self.spin_button.config(state=tk.DISABLED)


    def increase_bet(self):
        if self.bet < self.credits:
            self.bet += 1
            self.bet_label.config(text=f"Bet: {self.bet}")
            self.update_credits_display()


    def decrease_bet(self):
        if self.bet > 1:
            self.bet -= 1
            self.bet_label.config(text=f"Bet: {self.bet}")
            self.update_credits_display()
            
    def max_bet(self):
        self.bet = self.credits
        self.bet_label.config(text=f"Bet: {self.bet}")
        self.update_credits_display()
            
    def zero_bet(self):
        self.bet = 0
        self.bet_label.config(text=f"Bet: {self.bet}")
        self.update_credits_display()


    def start_spin(self):
        if not self.spinning and self.credits >= self.bet:
            self.credits -= self.bet
            self.spinning = True
            self.update_credits_display()
            self.start_fruit = 'X'
            self.spin_button.config(state=tk.DISABLED)
            
            self.generator.pretend_generate()
            
            # Generate target symbols
            self.target_symbols = [self.generator.generate_choice(SYMBOLS) for _ in range(5)]
            
            for i in range(5):
                if self.generator.generate_int(1,100) == 7:
                    self.target_symbols[i] = '🍒'
            
            self.spin_counter = 5  # Track active spinning reels
            
            # Start spinning each reel
            for i in range(5):
                self.animate_reel(i, self.target_symbols[i])       


    def animate_reel(self, reel_index, target_symbol):
        spin_steps = self.generator.generate_int(MIN_SPIN_STEPS, MAX_SPIN_STEPS)
        sequence = [self.generator.generate_choice(SYMBOLS) for _ in range(spin_steps)]
        sequence.append(target_symbol)
        current_step = 0

        def update_reel():
            nonlocal current_step
            if current_step < len(sequence):
                self.reel_labels[reel_index].config(text=sequence[current_step])
                current_step += 1
                self.root.after(SPIN_DELAY * current_step, update_reel) #Makes the slots slowly come to a stop
            else:
                self.spin_counter -= 1
                if self.spin_counter == 0:
                    self.spin_finished()

        update_reel()


    def spin_finished(self):
        self.spinning = False
        self.update_credits_display()
        #self.generator.reset_runs() For easy probability testing
        
        # Check for win
        if all(symbol == self.target_symbols[0] for symbol in self.target_symbols):
            payout = self.bet * SYMBOL_PAYOUT[self.target_symbols[0]]
            self.credits += payout
            self.update_credits_display()
            messagebox.showinfo("Winner!", f"JACKPOT! Five {self.target_symbols[0]}s!\n"f"You won {payout} credits!")
                
        elif all(symbol in {'🍎', '🍏'} for symbol in self.target_symbols):
            payout = self.bet * 2
            self.credits += payout
            self.update_credits_display()
            messagebox.showinfo("Winner!", f"JACKPOT! 5 Apples!\n"f"You won {payout} credits!")
            
        elif self.target_symbols.count('🍒') > 0:
            payout = self.bet
            self.credits += payout
            self.update_credits_display()
            messagebox.showinfo("Even", f"A cherry!\n"f"You get your money back!")
             
        else:
            messagebox.showinfo("Result", "No win this time. Try again!")
            
            
    def show_support(self):
        messagebox.showinfo("For support Call 0411 2342 2211", "Unique Machine ID: " + str(MACHINE_ID))

if __name__ == "__main__":
    root = tk.Tk()
    root.configure(bg='#8886dc') # Eureka Machine is: #8886dc, RedBack Machine is #dc8686
    game = PokiesGame(root)
    root.mainloop()
