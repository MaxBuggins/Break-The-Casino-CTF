### Produced by B.B.Coding - 2001 ###
# Developed by Carl Body, Jane Waver, Ted Black
# For Annoymous client - NOT TO BE SHARED FURTHER


#import math # While handy, we want as little external factors as possible (requirement change, Ugh!)
import datetime # In talks with the client, we may be able to agree upon an exception

class RanBug:
    def __init__(self, seed):
        self.seed = seed
        self.runs = 0
    
class RanBug:
    def __init__(self, seed):
        self.seed = seed
        self.runs = 0
    
    def generate_value(self):
        #Date stuff
        today = datetime.datetime.today()
        date_int = int(f"{today.day}{today.month}{today.year}")
        
        #Time Stuff
        now = datetime.datetime.now().replace(microsecond=0)
        start_of_day = now.replace(hour=0, minute=0, second=0)
        seconds_today = int((now - start_of_day).total_seconds())
    
        x = (self.seed + (self.runs * 7) + seconds_today + date_int) / 1000.0
    
        #Aparently this is very simmilar to sine waves: sin(x) ≈ x - x³/6
        x3 = x * x * x #NO MATH LIBARY THIS IS FINE
        sine_value = x - (x3 / 6.0)
    
        # Clamp the values to 0-1
        result = self.normalize_to_less_than_one(sine_value)
     
        
        # Bad Algorithm        
        # Non-linear formula, should be a more drastic change over time 
        # Fixes same results occuring close to each other
        # basic = (self.seed + self.runs) ** 7
        # quick = (seconds_today * 12345) ^ (date_int + self.runs) 
        # result2 = basic * quick
        
        # Reverse it because it works
        result_str = str(result)
        reversed_str = result_str[::-1]
        result_float = float(f"0.{reversed_str[:7]}")  # 7 digits are more than enough
        
        #print("Bad: " + str(result_float))
        print("Good: " + str(result_float))
        
        self.runs += 1
        return result_float
    
    def generate_int(self, minInt, maxInt):        
        result = self.generate_value()      
        NewRange = (maxInt - minInt)  
        result = (result * NewRange) + minInt
        return int(result)
        
    def generate_choice(self, symbols):        
        index = int((self.generate_value() * 1000) % len(symbols))
        return symbols[index]
        
        #This will generate without adding to the runs count, identical to generate value
    def pretend_generate(self):
        result = 0
        
        #Date stuff
        today = datetime.datetime.today()
        date_int = int(f"{today.day}{today.month}{today.year}")
        
        #Time Stuff
        now = datetime.datetime.now().replace(microsecond=0)
        start_of_day = now.replace(hour=0, minute=0, second=0)
        seconds_today = int((now - start_of_day).total_seconds())
    
        x = (self.seed + (self.runs * 7) + seconds_today + date_int) / 1000.0
    
        #Aparently this is very simmilar to sine waves: sin(x) ≈ x - x³/6
        x3 = x * x * x #NO MATH LIBARY THIS IS FINE
        sine_value = x - (x3 / 6.0)
    
        # Clamp the values to 0-1
        result = self.normalize_to_less_than_one(sine_value)       
        # Reverse it because it works
        result_str = str(result)
        reversed_str = result_str[::-1]
        result_float = float(f"0.{reversed_str[:10]}")  # 10 digits are more than enough
        
        print("===========================")
        print("Seed is: " + str(self.seed))
        print("Run count is: " + str(self.runs))
        print("seconds today is: " + str(seconds_today))
        print("and the date is: " + str(date_int))
        print("DATETIME IS: " + str(now))
  
        
        print(result)
            
        return result
        
    def reset_runs(self):
        self.runs = 0
        
    #Converts a number like 72342.2 to 0.723422
    def normalize_to_less_than_one(self, number):

        #Negative doesnt work
        abs_number = abs(number)
    
        #Count digits in the integer part
        int_part = int(abs_number)
        
        #Already less than 1 so all good
        if int_part == 0:
            return number 
    
        #how much digits and then apply those digits
        n = len(str(int_part))
        normalized =(abs_number / (10 ** n))
        
        return normalized
        
        
        
        
    # SERIOUSLY DONT JUST ADD STEPS TILL IT WORKS!!!! 
    # This is bloat, who F*c%ing gave me these code monkeys
    #def first_n_digits(self, num, n):
        #return num // 10 ** (int(math.log(num, 10)) - n + 1)



# TESTING
#seed = input("Press Enter Seed")
#generator = RanBug(int(seed))
#print("Final Result: " + str(generator.generate_int(1,100)))

#symbols = ['A', 'B', 'C', 'D', 'E']

#print(generator.generate_choice(symbols))  # Example: 'B'
#print(generator.generate_choice(symbols))  # Example: 'D'
#print(generator.generate_choice(symbols))  # Example: 'A'
