const express = require('express');
const path = require('path');
const app = express();
const port = 3000;

// Set up EJS for templating
app.set('view engine', 'ejs');

// Sample product data
const products = [
    { id: 1, name: 'Golden Slots', description: 'Try your luck and hit the jackpot!', jackpot: '$1,000,000' },
    { id: 2, name: 'Blackjack Royale', description: 'Beat the dealer and double your money.', jackpot: '$500,000' },
    { id: 3, name: 'High Stakes Poker', description: 'Join high rollers and test your skills.', jackpot: '$250,000' },


];
// Secret Admin Leak (Hidden)
const casinoReports = `
---- Casino Payout Report ----
- VIP Player "LuckyJohn" → Won: $500,000 (House-Approved)
- VIP Player "CasinoBoss" → Won: $1,000,000 (Owner Account)
- Regular Player "UnluckyJoe" → Won: $0 (Intentionally Blocked)
- High Roller "BigBets123" → Won: $10,000 (Reversed)

---- Hidden Scripts ----
- Rigged Slots Script: A script that ensures the house always wins.
- VIP Payout List: List of VIP players and their controlled winnings.
- Hidden Payout Adjuster: Tool to modify player balances without their knowledge.
`;

// Move the flag to an environment variable (more secure)
const FLAG = process.env.FLAG || 'IJQWYYLOMNSVWJBRGI4CYNRVHFOQ====';

// Home route
app.get('/', (req, res) => {
    res.render('index', { products });
});

// Search route (prevents NoSQL injection)
app.get('/search', (req, res) => {
    const query = req.query.q || '';
    const filteredProducts = products.filter(product =>
        product.name.toLowerCase().includes(query.toLowerCase())
    );
    res.render('index', { products: filteredProducts });
});

// Secure Admin Route
app.get('/admin', (req, res) => {
    let file = req.query.file;

    if (file === 'flag.txt') {
        res.type('text/plain').send(`
        *****Unauthorised access is strictly denied!*****

        ${casinoReports}

        ${FLAG}

        `);
    } else {
        res.status(403).send("Access Denied");
    }
});

// Start the server
app.listen(port, () => {
    console.log(`Server running at http://localhost:${port}`);
});
