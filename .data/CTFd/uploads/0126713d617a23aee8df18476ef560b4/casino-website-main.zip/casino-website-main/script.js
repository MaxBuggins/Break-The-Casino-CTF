// Flag: flag{theme_toggle_in_javascript}

/**
 * Function to toggle between light and dark theme
 */
function toggleTheme() {
    const body = document.body;
    body.classList.toggle('dark-theme');
    body.classList.toggle('light-theme');
}

// Set the initial theme based on user's preference or default to light
if (localStorage.getItem('theme') === 'dark') {
    document.body.classList.add('dark-theme');
} else {
    document.body.classList.add('light-theme');
}

// Attach the event listener to the theme toggle button
document.getElementById('theme-toggle').addEventListener('click', function() {
    toggleTheme();
    // Save the user's theme preference
    localStorage.setItem('theme', document.body.classList.contains('dark-theme') ? 'dark' : 'light');
});

// Slot Machine Game Logic
document.getElementById('play-btn').addEventListener('click', function() {
    const slot1 = document.getElementById('slot1');
    const slot2 = document.getElementById('slot2');
    const slot3 = document.getElementById('slot3');
    const result = document.getElementById('result');

    const symbols = ['🍒', '🍋', '🍉', '🍇', '🍊'];

    slot1.textContent = symbols[Math.floor(Math.random() * symbols.length)];
    slot2.textContent = symbols[Math.floor(Math.random() * symbols.length)];
    slot3.textContent = symbols[Math.floor(Math.random() * symbols.length)];

    if (slot1.textContent === slot2.textContent && slot2.textContent === slot3.textContent) {
        result.textContent = "You win!";
    } else {
        result.textContent = "Try again!";
    }
});

// Jackpot Spin Logic
document.getElementById('jackpot-btn').addEventListener('click', function() {
    const jackpotResult = document.getElementById('jackpot-result');
    const jackpotAmount = Math.floor(Math.random() * 10000) + 1; // Jackpot range 1 to 10,000

    jackpotResult.textContent = `You've won $${jackpotAmount}! 🎉`;
});
/* Hidden Flag 3/3: ,585] */
